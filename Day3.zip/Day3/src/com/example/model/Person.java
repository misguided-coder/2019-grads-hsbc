package com.example.model;

public class Person {
	
	protected String uid = "7229222828282";
	protected String name = "Pintu";
}
