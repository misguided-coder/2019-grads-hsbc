package com.example.exercise;

public interface Repairable {
	void repair();
}
