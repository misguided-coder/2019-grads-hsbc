package com.example.exercise;

public interface Washable {
	void wash();
}
