package com.example.exercise;

public abstract class Vehicle implements Automobile {

	public void stop() {
		System.out.println("Vehicle Stopped!!!");
	}
}
