package com.example.exercise;

public interface Brakable {
	void speedDown();
}
