package com.example.exercise;

public interface Automobile {
	public abstract void start();
	public abstract void stop();
}
