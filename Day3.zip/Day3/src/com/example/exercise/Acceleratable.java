package com.example.exercise;

public interface Acceleratable {
	void speedUp();
}
