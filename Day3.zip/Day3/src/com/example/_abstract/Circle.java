package com.example._abstract;

class Circle extends Shape {

	void draw() {
		System.out.println("Circle is drawn on canvas!!");
	}
	
	void paint() {
		System.out.println("Circle is painted with hand!!");
	}
	
}
