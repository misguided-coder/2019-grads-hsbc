package com.example._abstract;

class Square extends Shape {

	void draw() {
		System.out.println("Square is drawn on paper!!");
	}
	
	void paint() {
		System.out.println("Square is painted with pencil brush!!");
	}
	
}
