package com.example._final;

public class SequenceGenerator extends Generator {

	/*long generate() {
		return (long)(Math.random()*20000);
	}*/
}
