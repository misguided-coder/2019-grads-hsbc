package com.example.service;

public class EmployeeDemo {
	
	public static void main(String[] args) {
		
		
		Employee employee = new Employee();
		employee.info();
		System.out.println(employee.id);
		System.out.println(employee.salary);
		
	}

}
