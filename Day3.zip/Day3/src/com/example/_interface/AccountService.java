package com.example._interface;

public interface AccountService {
	public abstract long open(String name);
}
