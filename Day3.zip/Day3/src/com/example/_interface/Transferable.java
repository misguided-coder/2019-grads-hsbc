package com.example._interface;

public interface Transferable {
	public abstract boolean transfer(long accountNo,String fromBranch,String toBranch);
}
