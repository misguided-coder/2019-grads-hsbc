package com.example._interface;

public interface Closable {
	public abstract boolean close(long accountNo);
}
