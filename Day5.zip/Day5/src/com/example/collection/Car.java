package com.example.collection;

public class Car {

}
