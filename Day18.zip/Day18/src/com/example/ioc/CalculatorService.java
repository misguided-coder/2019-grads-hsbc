package com.example.ioc;

public class CalculatorService {

	public int sum(int arg1, int arg2) {
		return arg1 + arg2;
	}
}
