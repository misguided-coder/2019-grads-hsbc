package com.example.ioc;

public class PersonalDetailService {

	public void info(String name,String phone) {
		System.out.printf("Name : %s%n",name);
		System.out.printf("Phone : %s%n",phone);
	}
}
