package com.example.object.creation;

public class CalculatorService {

	public int sum(int arg1, int arg2) {
		return arg1 + arg2;
	}
}
