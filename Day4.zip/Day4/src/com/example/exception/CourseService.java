package com.example.exception;

public class CourseService {

	void details() {
		
	}
}
