package com.example.cast;

public class Animal {

	void eat() {
		System.out.println("All Animals eat!!!!");
	}
}
