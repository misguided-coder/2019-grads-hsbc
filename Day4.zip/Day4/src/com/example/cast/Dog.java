package com.example.cast;

public class Dog extends Animal {

	void bark() {
		System.out.println("Dog can bark also!!!!");
	}
}
