package com.example.cast;

public class Cat extends Animal {

}
