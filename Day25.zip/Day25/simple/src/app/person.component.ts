import {Component} from "@angular/core";

@Component({
	selector:'app',
	template:`<div>
			<h1>Person Details</h1>
			Enter Name : <input type='text' value='{{name}}' /><br/>
			Enter Name : <input type='text' [value]='name' /><br/>
			Enter Name : <input type='text' [(ngModel)]='name' /><br/>
			<h2>Name : {{name}}</h2>
			<h2>Age : {{age * 5}}</h2>
			<h2>Phone : {{phone}}</h2>
			<h2>Personal Email : {{emails[0]}}</h2>
			<h2>Official Email : {{emails[1]}}</h2>
			<img width=100 height=100 src='assets/cool-kid.jpg' />
			<img [width]='size.w' [height]='size.h' [src]='logo' />
			<input type='button' value='Sleep' (click)='doSleep();' />
			<input type='button' value='Wakeup' (click)='doWakeup();' />
		  </div>`
})
export class PersonComponent {

	name:string = 'Pintu';
	age:number  = 20;
	phone:number;	
	logo:string = 'assets/person1.jpg';
	size = {w:100,h:100};
	emails = ['a@a.com','b@b.com','c@c.com'];
	
	constructor() {
		console.log('Inside PersonComponent constructor!!');
		this.phone = 9810000000;
	}

	doSleep() {
		console.log("Go and Sleep!!!!");
	}

	doWakeup() {
		console.log("Hello Wakeup, house is on fire!!!!");
	}
		
}


