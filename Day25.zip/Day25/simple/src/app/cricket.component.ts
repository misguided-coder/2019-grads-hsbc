import {Component} from "@angular/core";

@Component({
	selector:'cricket',
	template:`<div>
			<h1>Cricket Page</h1>
			<h2>{{title}}</h2>
			<h2>{{summary}}</h2>
		  </div>`
})
export class CricketComponent {

	title:string = 'Test Match';
	summary:string = 'Match will be on 20th Dec';
	
	constructor() {
		console.log('Inside CricketComponent constructor!!');
	}	
}


