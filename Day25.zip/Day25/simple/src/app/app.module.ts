//Angular imports
import {NgModule} from "@angular/core";
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

//Application imports
import {HelloComponent} from "./hello.component";
import {PersonComponent} from "./person.component";
import {NewsComponent} from "./news.component";
import {CricketComponent} from "./cricket.component";
import {HomeComponent} from "./home.component";
import {WeatherComponent} from "./weather.component";


@NgModule({
	imports:[BrowserModule,FormsModule],
	declarations:[
		HelloComponent,
		PersonComponent,
		NewsComponent,
		CricketComponent,
		WeatherComponent,
		HomeComponent
	],
	bootstrap:[HomeComponent]
})
export class AppModule { 

	constructor() {
		console.log('Inside AppModule constructor!!');
	}

}

