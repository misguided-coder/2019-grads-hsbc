import {Component,Input,Output,EventEmitter} from "@angular/core";

@Component({
	selector:'weather',
	template:`<div>
			<h1>Weather Page</h1>
			<h2>City : {{details.city}}</h2>
			<h2>Min Temp : {{details.min}}</h2>
			<h2>Max Temp : {{details.max}}</h2>
			<input type=button value='Update' (click)='doUpdate();' />
		  </div>`
})
export class WeatherComponent {

	@Input()
	details;
	
	@Output()
	update = new EventEmitter();
				
	constructor() {
		console.log('Inside WeatherComponent constructor!!');
	}	

	doUpdate() {
		console.log('Weather update is needed!!');
		this.update.emit();	
	}

}


