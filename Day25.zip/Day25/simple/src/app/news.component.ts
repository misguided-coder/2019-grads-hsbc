import {Component} from "@angular/core";

@Component({
	selector:'news',
	template:`<div>
			<h1>News Page</h1>
			<h2>{{title}}</h2>
			<h2>{{summary}}</h2>
		  </div>`
})
export class NewsComponent {

	title:string = 'Breaking News';
	summary:string = 'Training will finish at 8 PM';
	
	constructor() {
		console.log('Inside NewsComponent constructor!!');
	}	
}


