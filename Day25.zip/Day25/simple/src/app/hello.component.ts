import {Component} from "@angular/core";

@Component({
	selector:'app',
	template:'<h1>Today is last learning day</h1>'
})
export class HelloComponent {
	constructor() {
		console.log('Inside HelloComponent constructor!!');
	}
}


