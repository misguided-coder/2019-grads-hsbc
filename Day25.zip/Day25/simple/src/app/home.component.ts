import {Component} from "@angular/core";

@Component({
	selector:'app',
	template:`<div>
			<h1>Home Page</h1>
			<h2>{{title}}</h2>
			<hr/>
			<weather [details]='info' (update)='updateWeather()'></weather>
		  </div>`
})
export class HomeComponent {

	title:string = 'Weather Department Application';
	info = {city:'Pune',min:18,max:24};
	
	constructor() {
		console.log('Inside HomeComponent constructor!!');
	}

	updateWeather() {
		console.log('HomeComponent updating the weather!!');
		this.info = {
			city : 'Pune',
			min : 20,
			max : 30
		};
	}	
}


