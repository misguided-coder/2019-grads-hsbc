package com.example.factory;

public class Desk extends Furniture  {
	
	public void make() {
		System.out.println("Desk is ready!!");
	}

	public void paint() {
		System.out.println("Desk is painted!!");
	}
}
