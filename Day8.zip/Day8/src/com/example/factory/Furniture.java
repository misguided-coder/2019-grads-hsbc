package com.example.factory;

public class Furniture {
	
	public void make() {
		System.out.println("Furniture is ready!!");
	}

	public void paint() {
		System.out.println("Furniture is painted!!");
	}
}
