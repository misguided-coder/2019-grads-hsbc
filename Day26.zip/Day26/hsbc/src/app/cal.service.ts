export class CalService {
	
	constructor() {
		console.log("=====  Inside CalService constructor() =====");
	}

	doSum(firstNumber:number,secondNumber:number) {
		console.log("=====  Inside CalService doSum() =====");
		return firstNumber + secondNumber;
	}


	doDiff(firstNumber:number,secondNumber:number) {
		console.log("=====  Inside CalService doDiff() =====");
		return firstNumber - secondNumber;
	}


	doMultiply(firstNumber:number,secondNumber:number) {
		console.log("=====  Inside CalService doMultiply() =====");
		return firstNumber * secondNumber;
	}



	doDivide(firstNumber:number,secondNumber:number) {
		console.log("=====  Inside CalService doDivide() =====");
		return firstNumber / secondNumber;
	}
	
}
