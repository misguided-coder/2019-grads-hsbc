import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app',
  template: `<div>
		<h2>{{title}}</h2>					
		<h2>VIN : {{car.vin}}</h2>
		<h2>Name : {{car.model}}</h2>
		<h2>Price : {{car.price}}</h2>
		<input type='button' value='LOAD' (click)='doAJAX();' />
   	     </div>`
})
export class CarDetailComponent {

	title = 'Car Wish List';
	car = {};

	constructor(private httpClient:HttpClient) {
	}
	
	doAJAX() {
		console.log("=====  Inside CarDetailComponent load() =====");
		let restURI = 'http://localhost:5000/api/car/101';
		/*var observable = this.httpClient.get(restURI);
		observable.subscribe((data)=>{
			console.log("Response received!!");
			this.car = data;
		});*/

		this.httpClient.get(restURI).subscribe((data)=>{
			this.car = data;
		});

 
		console.log("=====  AJAX call done =====");
	}

}
