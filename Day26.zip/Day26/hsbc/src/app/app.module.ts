import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

import { CalService } from './cal.service';

import { CalComponent } from './cal.component';
import { CarDetailComponent } from './car-detail.component';


@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule 
  ],
  declarations: [
    CalComponent,
    CarDetailComponent
  ],
  providers:[
    CalService 
  ],
  bootstrap: [CarDetailComponent]
})
export class AppModule { }
