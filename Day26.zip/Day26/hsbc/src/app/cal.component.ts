import { Component } from '@angular/core';

import { CalService } from './cal.service';

@Component({
  selector: 'app',
  template: `<div>
		<h2>{{title}}</h2>					
		Enter Number : <input type='number' [(ngModel)]='firstNumber' /><br/>
		Enter Number : <input type='number' [(ngModel)]='secondNumber' /><br/>
		<input type='button' value='SUM' (click)='sum();' />
		<input type='button' value='DIFF' (click)='diff();' />
		<br/>
		<h1>Result : {{result}}</h1>
   	     </div>`
})
export class CalComponent {

	title = 'Simple Math Calculator';
	firstNumber:number = 10;
	secondNumber:number = 5;
	result = 0;

	constructor(private calService:CalService) {
		//this.calService = calService;
	}
	
	//Event handler functions
	sum() {
		console.log("=====  Inside CalComponent sum() =====");
		//Delegate calls to business services
		this.result = this.calService.doSum(this.firstNumber,this.secondNumber);
	}

	//Event handler functions
	diff() {
		console.log("=====  Inside CalComponent diff() =====");
		//Delegate calls to business services
		this.result = this.calService.doDiff(this.firstNumber,this.secondNumber);
	}

		
}
