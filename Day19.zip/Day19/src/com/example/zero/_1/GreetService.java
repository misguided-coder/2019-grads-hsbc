package com.example.zero._1;

public class GreetService {

	public void greet(String name) {
		System.out.printf("Hello Mr. %s%n", name);
	}

}
