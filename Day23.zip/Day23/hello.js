var i = 10;
var j = 10;
var rs = i +j;

console.log(rs);

function greet(name) {
	console.log("Hello "+name);
}

greet("Jaggu");

for(var idx=0;idx<10;idx++) {
	console.log("Index  : "+idx);
}

var d = new Date();
console.log(d.getMonth());
console.log(d);

var array = [45,23,45,67,8,55,44,22];
array.push(12);
console.log(array);

