function hello() {
	console.log("Hello ji");
}

hello();

//fat arrow function
var hi = (name) => {
	console.log("Hi "+name);
}

hi();
hi('Raj');
