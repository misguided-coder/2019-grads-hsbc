package com.example.jdbc.dml;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

//CRUD Demo
public class Main {

	public static void main(String[] args) {
		new Main();
	}

	public Main() {
		//save();
		//saveDynamicData();
		saveMoreData();
	}
	
	//Using paramateric queries
	private void saveMoreData() {
		
		Connection connection = null;
		PreparedStatement statement = null;

		try {
			// Load JDBC Driver
			Class.forName("org.apache.derby.jdbc.ClientDriver");

			// Make a Connection
			connection = DriverManager.getConnection("jdbc:derby://localhost:4444/training");
			System.out.println("Connected to DB!!");

			// Create a Statement to run SQL queries
			//statement = connection.prepareStatement("INSERT INTO COURSE_MASTER VALUES(102,'EJB',24)");
			statement = connection.prepareStatement("INSERT INTO COURSE_MASTER VALUES(?,?,?)");

			statement.setInt(1, 103);
			statement.setString(2, "Spring");
			statement.setInt(3, 80);
			
			// Execute SQL queries
			statement.executeUpdate();
			System.out.println("Data Saved Successfully!!");

			// Handle result set
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			// Close DB Connection and other resources
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
					System.out.println("Disconnected from DB!!");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	
	private void saveDynamicData() {
		
		Connection connection = null;
		Statement statement = null;

		try {
			// Load JDBC Driver
			Class.forName("org.apache.derby.jdbc.ClientDriver");

			// Make a Connection
			connection = DriverManager.getConnection("jdbc:derby://localhost:4444/training");
			System.out.println("Connected to DB!!");

			// Create a Statement to run SQL queries
			statement = connection.createStatement();

			int courseId = 101;
			String title = "Hibernate";
			int duration = 60; //Hours
						
			// Execute SQL queries
			statement.executeUpdate("INSERT INTO COURSE_MASTER VALUES("+courseId+",'"+title+"',"+duration+")");
			System.out.println("Data Saved Successfully!!");

			// Handle result set
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			// Close DB Connection and other resources
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
					System.out.println("Disconnected from DB!!");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}


	private void save() {
		
		Connection connection = null;
		Statement statement = null;

		try {
			// Load JDBC Driver
			Class.forName("org.apache.derby.jdbc.ClientDriver");

			// Make a Connection
			connection = DriverManager.getConnection("jdbc:derby://localhost:4444/training");
			System.out.println("Connected to DB!!");

			// Create a Statement to run SQL queries
			statement = connection.createStatement();

			// Execute SQL queries
			statement.executeUpdate("INSERT INTO COURSE_MASTER VALUES(100,'JSP',40)");
			System.out.println("Data Saved Successfully!!");

			// Handle result set
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			// Close DB Connection and other resources
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
					System.out.println("Disconnected from DB!!");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
