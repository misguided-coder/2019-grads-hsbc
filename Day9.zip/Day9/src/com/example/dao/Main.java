package com.example.dao;

public class Main {

	public static void main(String[] args) {
		CourseDAO courseDAO = new CourseDAO();
		//courseDAO.readData();
		//courseDAO.updateCourse();
		//courseDAO.readData();
		//courseDAO.deleteCourse();
		courseDAO.readData();
		
		
	}
}
