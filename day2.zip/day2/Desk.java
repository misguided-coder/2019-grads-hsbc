class Desk extends Furniture {

	void make() {
		System.out.printf("Desk is made of %s%n",this.material);
	}

}
